-- Adminer 4.6.2 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `diplom` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `diplom`;

DROP TABLE IF EXISTS `answer`;
CREATE TABLE `answer` (
  `id` int(11) NOT NULL auto_increment,
  `text` text collate utf8_unicode_ci NOT NULL,
  `published` int(11) NOT NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `author`;
CREATE TABLE `author` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(250) collate utf8_unicode_ci NOT NULL,
  `email` varchar(250) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `question`;
CREATE TABLE `question` (
  `id` int(11) NOT NULL auto_increment,
  `question` text collate utf8_unicode_ci NOT NULL,
  `visible` int(11) default NULL,
  `aid` int(11) default NULL,
  `athid` int(11) default NULL,
  `sid` int(11) default NULL,
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `sid` (`sid`),
  KEY `aid` (`aid`),
  KEY `athid` (`athid`),
  CONSTRAINT `question_ibfk_6` FOREIGN KEY (`sid`) REFERENCES `subject` (`id`) ON DELETE SET NULL ON UPDATE NO ACTION,
  CONSTRAINT `question_ibfk_7` FOREIGN KEY (`aid`) REFERENCES `answer` (`id`) ON DELETE SET NULL ON UPDATE NO ACTION,
  CONSTRAINT `question_ibfk_8` FOREIGN KEY (`athid`) REFERENCES `author` (`id`) ON DELETE SET NULL ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `subject`;
CREATE TABLE `subject` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(250) collate utf8_unicode_ci NOT NULL,
  `enabled` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(250) collate utf8_unicode_ci NOT NULL,
  `password` varchar(60) collate utf8_unicode_ci NOT NULL,
  `email` varchar(60) collate utf8_unicode_ci NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `users` (`id`, `name`, `password`, `email`, `updated_at`, `created_at`) VALUES
(2,	'Иван',	'$2y$10$YpbrEPFdWW7KtBtW1WMM4eofZsdvPIq7Qr5JlaKJrOWuOpT154WfO',	'egge@ya.ru',	'2018-05-31 12:47:03',	'2018-05-31 12:47:03'),
(4,	'admin',	'admin',	'admin@admin',	'2018-06-01 13:19:55',	'2018-06-01 13:19:55'),
(5,	'admin',	'$2y$10$Qjb8O.j4s6Tmqf95G.2.fu7eShrfhsDfD5zKfolQmg56FrIdrkWVG',	'admin@admin.com',	'2018-06-01 10:32:17',	'2018-06-01 10:32:17');

-- 2018-06-01 10:33:36
